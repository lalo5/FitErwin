<?php
/**
 * Created by PhpStorm.
 * User: theedman
 * Date: 9/25/2018
 * Time: 4:31 PM
 */
?>
<html>
<table class="table">
        <thead>
        <tr scope = 'col'>
            <th>Username</th>
            <th>Steps</th>
            <th>Week</th>
            <th>Day of Week</th>
        </tr>
        </thead>


<tr>

</tr>

</table>