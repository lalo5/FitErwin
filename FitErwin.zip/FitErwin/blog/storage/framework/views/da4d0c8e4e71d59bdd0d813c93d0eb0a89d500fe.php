<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>FitErwin</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">




            <?php
            session_start();
            $errorMsg = "";

            $validUser = isset($_SESSION["login"]) === true;
            if(isset($_POST["sub"]))
            {
                $validUser = $_POST["username"] == "etsu" && $_POST["password"] == "fiterwin";
                if(!$validUser) $errorMsg = "Invalid username or password.";
                else $_SESSION["login"] = true;
            }
            if($validUser) {
               redirect('/dashboard'); die();
            }
            ?>

            <form name="input" action="" method="post">
                <label for="username">Username:</label><input type="text" value="" id="username" name="username" />
                <label for="password">Password:</label><input type="password" value="" id="password" name="password" />
                <div class="error"><?= $errorMsg ?></div>
                <input type="submit" value="Enter" name="sub"/>
            </form>


        </div>
    </body>
</html>
