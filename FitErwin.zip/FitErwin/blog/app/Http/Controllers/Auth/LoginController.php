<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function show()
    {
//        $roles = Role::paginate(1);
        return view('login.login');
    }

//    public function auth()
//    {
//        request()->validate([
//            'username' => 'required',
//            'password' => 'required'
//        ]);
//
////        $ldap = ldap_connect('ldap://etsu.edu');
////        ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
////        $username = explode('@', request('email'));
////
////        if($ldap)
////        {
////            $status = @ldap_bind($ldap, $username[0] . "@ETSU", request('password'));
////
////            $user = User::where('email', request('email'))->first();
////
////            if($status && $user)
////            {
////                ldap_unbind($ldap);
////                Auth::login($user);
////                return redirect('/dashboard');
////            }
////            else
////            {
////                return redirect('login');
////            }
////        }
//
////        $fiterwin = User::where('username' == 'etsu' && 'password' == 'fiterwinproject');
////
////        if($fiterwin)
////        {
////            Auth::login($fiterwin);
////            return redirect('/dashboard');
////        }
////        else
////        {
////            return redirect('login');
////        }
//
//    }

    public function logout()
    {
        Auth::logout();

        return redirect('login');
    }
}
